# PowerShell script to download example images into the project's public/images folder
# Run from project root (PowerShell):
# .\scripts\download-images.ps1

$images = @(
    @{url='https://images.unsplash.com/photo-1580281657523-6a8d1a3b6b5d?q=80&w=1400&auto=format&fit=crop&ixlib=rb-4.0.3&s=bd9f3a8f6e6f0eef'; out='public/images/nurse.jpg'},
    @{url='https://images.unsplash.com/photo-1537368910025-700350fe46c7?q=80&w=1400&auto=format&fit=crop&ixlib=rb-4.0.3&s=3a9c5f2b7b0a1a7e'; out='public/images/doctor.jpg'},
    @{url='https://images.unsplash.com/photo-1580281657521-7f5d6d8f45b2?q=80&w=1400&auto=format&fit=crop&ixlib=rb-4.0.3&s=abcd1234abcd1234'; out='public/images/patient.jpg'},
    @{url='https://images.unsplash.com/photo-1526256262350-7da7584cf5eb?q=80&w=1400&auto=format&fit=crop&ixlib=rb-4.0.3&s=mapimg'; out='public/images/map.jpg'},
    @{url='https://images.unsplash.com/photo-1586264662868-5b0c7b9f3efb?q=80&w=1400&auto=format&fit=crop&ixlib=rb-4.0.3&s=frontimg'; out='public/images/front.jpg'}
)

if(-not (Test-Path -Path 'public/images')){
    New-Item -ItemType Directory -Path 'public/images' -Force | Out-Null
}

foreach($img in $images){
    $outPath = $img.out
    try{
        Write-Host "Downloading $($img.url) -> $outPath"
        Invoke-WebRequest -Uri $img.url -OutFile $outPath -UseBasicParsing
    } catch {
        Write-Host "Failed to download $($img.url): $_"
    }
}

Write-Host "Done. Images saved to public/images"
